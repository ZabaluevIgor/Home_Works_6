package Home_Work_6;

public abstract class Animals {

    protected abstract String getName();
    protected abstract int getRunMAX();
    protected abstract int getSwimMAX();
    protected abstract float getJumpMAX();

    public void run(int distance) {
        boolean result = (distance <= getRunMAX());
            System.out.println(getName() + " пробежал " + distance + " метров." + result);
    }

    public void swim(int distance) {
        boolean result = (distance <= getSwimMAX());
            System.out.println(getName() + " проплыл " + distance + " метров." + result);
    }

    public void jump(float height) {
        boolean result = (height <= getJumpMAX());
            System.out.println(getName() + " прыгнул на " + height + " метров." + result);
    }

    public static void main(String[] args) {

        Dog dog = new Dog();
        Cat cat = new Cat();

        dog.run(800);
        dog.swim(5);
        cat.run(50);
        cat.jump(0.3f);

    }

//    protected int run;
//    protected int swim;
//    protected float jump;
//
//    public Animals(int run, int swim, float jump) {
//
//        this.run = run;
//        this.swim = swim;
//        this.jump = jump;
//    }
//
//    public void info () {
//        System.out.println("Животное: " + name);
//    }
//
//    public void run () {
//        System.out.println("Животное побежало.");
//    }
//
//    public void swim () {
//        System.out.println("Животное поплыло.");
//    }
//
//    public void jump () {
//        System.out.println("Животное прыгнуло.");
//    }

}

